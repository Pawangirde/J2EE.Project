package SingletonPackage;

public class Account {
	/**
	 * @param i
	 */
public	 int accountBalence;
private static Account account=new Account(10000);
	private Account(int accountBalence) {
		super();
		this.accountBalence = accountBalence;
	}
    public static Account getAccount(){
      return account;
}}
