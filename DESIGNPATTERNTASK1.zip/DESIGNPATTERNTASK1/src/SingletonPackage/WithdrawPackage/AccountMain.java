package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class AccountMain {
public static void main(String[] args) {
	
	Withdraw withdraw=new Withdraw();
	withdraw.withdrawAmount(2000);
	Deposit deposit=new Deposit();
	deposit.depositAmount(5000);
	CheckBalence balence=new CheckBalence();
	balence.checkBalence(0);
}
	
	
}
