package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class Withdraw {
	Account account=Account.getAccount();
	//int withdrawAmount;
	
	public void withdrawAmount(int withdrawAmount )
	
	{
		account.accountBalence-=withdrawAmount;
		System.out.println("Withdrawing Amount "+ withdrawAmount);
		
		
	}
	  
}
