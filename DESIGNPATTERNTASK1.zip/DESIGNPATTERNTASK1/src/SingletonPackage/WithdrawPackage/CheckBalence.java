package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class CheckBalence {
Account account=Account.getAccount();

   public void checkBalence(int checkBalence) {
	   account.accountBalence=checkBalence;
	   System.out.println("Available balence is "+ checkBalence);
   }
}
