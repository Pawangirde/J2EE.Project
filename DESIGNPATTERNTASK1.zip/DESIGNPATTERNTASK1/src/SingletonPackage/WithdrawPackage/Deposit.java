package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class Deposit {
	Account account=Account.getAccount();
      
	public void depositAmount(int depositAmount) {
		
		 account.accountBalence+=depositAmount;
       System.out.println("deposit Amount "+ depositAmount);
}
}