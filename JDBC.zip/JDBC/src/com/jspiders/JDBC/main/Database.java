package com.jspiders.JDBC.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {
	public static void main(String[] args) {
		try {

			// step 1: load the Driver class
			Class.forName("com.mysql.cj.jdbc.Driver");

			// step 2: open the connection
			Connection connection = DriverManager
					.getConnection("jdbc:mysql://localhost:3306/wajm4?user=root&password=root");

			// step 3: create statement
			Statement statement = connection.createStatement();

			ResultSet resultSet = statement.executeQuery("select * from banks");
			
//			step 4: process the result
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1)+" "+resultSet.getString(2)+" "+resultSet.getDouble(3));
			}
			//step 5: close connection
			connection.close();
			statement.close();
			resultSet.close();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
