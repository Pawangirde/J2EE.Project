package FactoryDesignPattern.items.cafe;

import FactoryDesignPattern.items.Order;

public class Fries implements Order {

	@Override
	public void orderItems() {
		System.out.println("ordering Fries");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Fries Ready");

	}
}
