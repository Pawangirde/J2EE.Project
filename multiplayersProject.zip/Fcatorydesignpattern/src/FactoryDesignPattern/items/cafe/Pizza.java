package FactoryDesignPattern.items.cafe;

import FactoryDesignPattern.items.Order;

public class Pizza implements Order {

	@Override
	public void orderItems() {
		System.out.println("ordering pizza");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		System.out.println("pizaa ready");
	}
}
