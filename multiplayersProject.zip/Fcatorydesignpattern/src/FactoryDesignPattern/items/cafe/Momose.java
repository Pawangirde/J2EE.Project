package FactoryDesignPattern.items.cafe;

import FactoryDesignPattern.items.Order;

public class Momose implements Order{
	public void orderItems() {
		System.out.println("ordering Momose");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Momose Ready");

}
}