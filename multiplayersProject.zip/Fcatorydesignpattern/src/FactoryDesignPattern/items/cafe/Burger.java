package FactoryDesignPattern.items.cafe;

import FactoryDesignPattern.items.Order;

public class Burger implements Order {

	@Override
	public void orderItems() {
		System.out.println("ordering Burger");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Burger Ready");

	}

}
