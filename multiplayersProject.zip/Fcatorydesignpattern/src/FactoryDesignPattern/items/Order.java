package FactoryDesignPattern.items;

public interface Order {
void orderItems();
}
