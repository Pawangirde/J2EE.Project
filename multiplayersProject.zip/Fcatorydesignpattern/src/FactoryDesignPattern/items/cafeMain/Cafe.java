package FactoryDesignPattern.items.cafeMain;

//package FactoryDesignPattern.items.cafe;



import java.util.Scanner;

import FactoryDesignPattern.items.Order;
import FactoryDesignPattern.items.cafe.Burger;
import FactoryDesignPattern.items.cafe.Coffie;
import FactoryDesignPattern.items.cafe.Fries;
import FactoryDesignPattern.items.cafe.Momose;
import FactoryDesignPattern.items.cafe.Pasta;
import FactoryDesignPattern.items.cafe.Pizza;

public class Cafe {
	private static Order order;
	private static boolean loop=true;
	private static int choose;
	private static Scanner scanner=new Scanner(System.in);
	public static void main(String[] args) {
		    while (loop) {
		    	factory();
				order.orderItems();
			}
				
			
	}
	private static Order factory() {
		System.out.println("=====Menu=====\n"
				+ "Pizza\n"
				+ "Burger\n"
				+ "Fries\n"
				+ "Coffie\n"
				+ "Pasta\n"
				+ "Momose");
		choose=scanner.nextInt();
		switch (choose) {
		case 1:
			order=new Pizza();
			break;
		case 2:
			order=new Burger();
			break;
		case 3:
			order=new Fries();
			break;
		case 4:
			order=new Coffie();
			break;
		case 5:
			order=new Pasta();
			break;
		case 6:
			order=new Momose();
			break;
		case 7:
			System.out.println("Thanks You Visit Again");
			//loop=false;
			break;
         default:
        	 System.out.println("Invalid Choice");
        	 order=null;
			break;
		}
		return order;
		
	}


	

}

