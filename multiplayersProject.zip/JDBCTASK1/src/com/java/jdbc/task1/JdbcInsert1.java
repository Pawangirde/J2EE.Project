package com.java.jdbc.task1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import com.mysql.cj.protocol.Resultset;

public class JdbcInsert1 {
	private static Connection connection;
	private static Statement statement;
	private static ResultSet resultset;
	private static int result;
	private static String filepath = "C:\\J2EE\\JDBCTASK1\\Resources\\db_info.properties";
	private static FileReader fileReader;
	private static Properties properties;

	public static void main(String[] args) {

		try {
			// filereader object class
			fileReader = new FileReader(filepath);

			properties = new Properties();
			properties.load(fileReader);
			// loading driverclass
			Class.forName(properties.getProperty("driverpath"));

			connection = DriverManager.getConnection(properties.getProperty("dburl"), properties);

			statement = connection.createStatement();

//			task1: create a table
			
//			result = statement.executeUpdate(properties.getProperty("query1"));
//			System.out.println(result + " row(s) affected");
			
//			task 2: insert 5 records
			
//			result = statement.executeUpdate(properties.getProperty("query2"));
//			System.out.println(result + " row(s) affected");

//			task 3:display all record
			
//			resultset = statement.executeQuery(properties.getProperty("query3"));
//
//			while (resultset.next()) {
//				System.out.println(resultset.getString(1) + " | " + resultset.getString(2) + " | "
//						+ resultset.getString(3) + " | " + resultset.getString(4));
//			}
			
//			task 4: update 2 records

//			result = statement.executeUpdate(properties.getProperty("query4"));
//			System.out.println(result + " row(s) affected");
//
			
//			result = statement.executeUpdate(properties.getProperty("query5"));
//			System.out.println(result + " row(s) affected");
//
//			task 5: display all record
			
//			resultset = statement.executeQuery(properties.getProperty("query3"));
//
//			while (resultset.next()) {
//				System.out.println(resultset.getString(1) + " | " + resultset.getString(2) + " | "
//						+ resultset.getString(3) + " | " + resultset.getString(4));
//			}

//			task 6: delete 1 record
			
//			result = statement.executeUpdate(properties.getProperty("query6"));
//			System.out.println(result + " row(s) affected");
			
//			task 7: display all records
			
			resultset = statement.executeQuery(properties.getProperty("query7"));
			
						while (resultset.next()) {
							System.out.println(resultset.getString(1) + " | " + resultset.getString(2) + " | "
									+ resultset.getString(3) + " | " + resultset.getString(4));
						}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (SQLException e2) {
			}
		}
	}
}
