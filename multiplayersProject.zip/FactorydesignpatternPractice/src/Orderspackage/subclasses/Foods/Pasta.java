package Orderspackage.subclasses.Foods;

import Orderspackage.Order;

public class Pasta implements Order {

	@Override
	public void orderItem() {
    System.out.println("ordering Pasta");
try {
	Thread.sleep(3000);
} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
System.out.println("Pasta ready");
	}

}
