package Orderspackage.subclasses.Foods;

import Orderspackage.Order;

public class Pizza implements Order {

	public void orderItem() {
		System.out.println("ordering pizza");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("order ready");
	}
}
