package Orderspackage.subclasses.Foods;

import Orderspackage.Order;

public class Burger implements Order{

	public void orderItem() {
		// TODO Auto-generated method stub
		System.out.println("ordering Burger");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Burger ready");
	}
	
}

	


