package Orderspackage.Main;

import java.util.Scanner;

import Orderspackage.Order;
import Orderspackage.subclasses.Foods.Burger;
import Orderspackage.subclasses.Foods.Pasta;
import Orderspackage.subclasses.Foods.Pizza;

public class Cafe {
	private static Order order;
	private static int choice;
	static boolean loop = true;
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		while (loop) {
			factory();
			order.orderItem();
		}

	}

	private static Order factory() {
		System.out.println("****MENU*****\n" + "1.Pizza\n" + "2.Pasta\n" + "3.Burger\n");
		choice = scanner.nextInt();

		switch (choice) {
		case 1:
			order = new Pizza();

			break;
		case 2:
			order = new Pasta();
			break;
		case 3:
			order = new Burger();
			break;
		case 4:
			System.out.println("Thanku visit again");
			loop = false;
			break;
		default:
			System.out.println("Invalid choice");
			order = null;
			break;
		}

		return order;
	}

}
