package com.jspiders.multithreadingwaitandnotify.thread;

import com.multuthreadingwaitandnotify.resources.shop.Customer;
import com.multuthreadingwaitandnotify.resources.shop.Shop;
import com.multuthreadingwaitandnotify.resources.shop.Supplier;

public class ShopMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Shop shop=new Shop(100);
      Customer customer=new Customer(shop, 50);
      Customer customer2=new Customer(shop, 70);
      Supplier supplier=new Supplier(shop, 100);
      
      customer.start();
      customer2.start();
      supplier.start();
	}

}
