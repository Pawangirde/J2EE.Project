package com.multuthreadingwaitandnotify.resources.shop;

public class Supplier extends Thread {
private Shop shop;
private int noofproducts;
public Supplier(Shop shop, int noofproducts) {
	super();
	this.shop = shop;
	this.noofproducts = noofproducts;
}
@Override
	
		public void run() {
			// TODO Auto-generated method stub
			shop.restockproducts(noofproducts);
		}
}
