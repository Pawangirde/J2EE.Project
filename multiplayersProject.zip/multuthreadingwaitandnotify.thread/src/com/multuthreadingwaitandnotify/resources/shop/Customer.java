  package com.multuthreadingwaitandnotify.resources.shop;

public class Customer extends Thread{
    private Shop shop;
    private int noofproduct;
    
	public Customer( Shop shop, int noofproduct) {
		super();
		this.shop = shop;
		this.noofproduct = noofproduct;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		shop.restockproducts(noofproduct);
	}
}
