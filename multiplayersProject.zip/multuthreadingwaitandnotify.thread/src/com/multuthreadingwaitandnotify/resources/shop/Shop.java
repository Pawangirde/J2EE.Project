package com.multuthreadingwaitandnotify.resources.shop;

public class Shop {

	int noofproducts;

	public Shop(int noofproducts) {
		super();
		this.noofproducts = noofproducts;
	}
   public synchronized void restockproducts(int restockproducts) {
	   noofproducts +=restockproducts;
	   System.out.println(restockproducts+"successfully added to the stock");
	   System.out.println("now available products :"+noofproducts);
	   this.notify();
   }
public synchronized void purchesproducts(int purchesproducts)
{
	if (noofproducts<purchesproducts) {
		System.out.println(purchesproducts+"product not available plz wait");
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	noofproducts-=purchesproducts;
	System.out.println(purchesproducts+"successfully added");
	System.out.println("now available product : "+noofproducts);
}

}
