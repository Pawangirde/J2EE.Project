package ADP.Interface;

public interface Mock {
	void rating();

}
