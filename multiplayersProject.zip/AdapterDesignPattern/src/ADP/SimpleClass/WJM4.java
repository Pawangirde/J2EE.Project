package ADP.SimpleClass;

public class WJM4 {
	private int id;
	private String name;
	private String tech_rating;
	private String comm_rating;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTech_rating() {
		return tech_rating;
	}

	public void setTech_rating(String tech_rating) {
		this.tech_rating = tech_rating;
	}

	public String getComm_rating() {
		return comm_rating;
	}

	public void setComm_rating(String comm_rating) {
		this.comm_rating = comm_rating;
	}

}
