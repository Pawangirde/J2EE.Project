package ADP.Adapter.main;

import ADP.Interface.Mock;
import ADP.SimpleClass.WJM4;

public class AdapterMain extends WJM4 implements Mock {

	static AdapterMain adapter = new AdapterMain();

	public static void main(String[] args) {

		adapter.rating();
	}

	@Override
	public void rating() {
		adapter.setId(1);
		adapter.setName("Pawan");
		adapter.setTech_rating("*");
		adapter.setComm_rating("1");

		System.out.println(adapter.getName() 
				+ " is get " + adapter.getTech_rating() + " in technical and "
				+ adapter.getComm_rating() + " in communication");

	}
}
