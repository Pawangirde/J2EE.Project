package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class Deposit {
	/**
	 * @param account
	 * @param depositAmount
	 */
	public Deposit(Account account, int depositAmount) {
		super();
		this.account = account;
		this.depositAmount = depositAmount;
	}

	Account account;
	int depositAmount;

	public synchronized void deposit(int depositAmount) {

		account.accountBalence += depositAmount;
		System.out.println("depositing Amount " + depositAmount);
		System.out.println("Available Balence :- " + account.accountBalence);
	}

}