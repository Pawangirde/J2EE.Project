package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class Withdraw {

	Account account;
	int withdrawAmount;

	public Withdraw(Account account, int withdrawAmount) {
		super();
		this.account = account;
		this.withdrawAmount = withdrawAmount;
	}

	public synchronized void withdra(int withdrawAmount)

	{

		if (account.accountBalence <= withdrawAmount) {
			System.out.println("Insufficient Balence" + withdrawAmount);
		} else {
			account.accountBalence -= withdrawAmount;
			System.out.println("Available Amount " + account.accountBalence);
		}
	//	System.out.println("Available Balence :- " + account.accountBalence);

	}

}
