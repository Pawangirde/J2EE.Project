package SingletonPackage.WithdrawPackage;

import java.util.Scanner;

import SingletonPackage.Account;

public class AccountMain {
	static Account account = Account.getAccount();
	static int choose;
	static boolean loop = true;
	private static int password;
	private static int password1;
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Set the Password......");
		password = scanner.nextInt();
		System.out.println("Enter the Password Again.....");
		password1 = scanner.nextInt();
		if (password == password1) {

			while (loop) {

				System.out
						.println("==MAIN==\n" + "1.Withdrawing Amount\n" + "2.Depositing Amount\n" + "3.CheckBalence");

				choose = scanner.nextInt();
				switch (choose) {
				case 1:
					System.out.println("Enter the Amount Of Withdrawing");
					int withdrawAmount = scanner.nextInt();
					Withdraw withdraw = new Withdraw(account, withdrawAmount);

					withdraw.withdra(withdrawAmount);

					break;
				case 2:
					System.out.println("Enter the Amount Of Depositing");
					int depositAmount = scanner.nextInt();
					Deposit deposit = new Deposit(account, depositAmount);
					deposit.deposit(depositAmount);

					break;
				case 3:

					CheckBalence balence = new CheckBalence(account);
					balence.checkBal();
					break;

				case 4:
					String str = "Thanks for visiting........ ";
					for (int i = 0; i < str.length(); i++) {
						System.out.print(str.charAt(i));
						try {
							Thread.currentThread().sleep(200);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
//					System.out.print(str);
					}
					// System.out.println();
					loop = false;
					break;

				}

			}
		} else {
			System.out.println("Enter Correct Password.........");
		}
	}
}
