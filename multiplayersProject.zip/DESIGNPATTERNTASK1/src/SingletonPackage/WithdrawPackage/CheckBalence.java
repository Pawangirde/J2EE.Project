package SingletonPackage.WithdrawPackage;

import SingletonPackage.Account;

public class CheckBalence {
	/**
	 * @param account
	 */
	public CheckBalence(Account account) {
		super();
		this.account = account;
	}

	/**
	 * @param account
	 * @param checkbalence
	 */
	Account account;
	// int checkBalence;

	public synchronized void checkBal() {
		try {
			Thread.currentThread().sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("Available balence is " + account.accountBalence);

		// System.out.println("Insufficient Fund");

	}
}
