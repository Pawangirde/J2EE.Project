package com.jsp.multithreading.main;

import com.jsp.multithreading.threads.MyThread1;

public class MainThread1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     MyThread1 mThread1=new MyThread1();
     mThread1.start();
	}

}
