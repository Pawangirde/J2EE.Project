package com.jsp.multithreading.main;

import com.jsp.multithreading.threads.MyThread1;
import com.jsp.multithreading.threads.MyThread2;
import com.jsp.multithreading.threads.MyThread3;
import com.jsp.multithreading.threads.MyThread4;

public class MainThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 MyThread1 mThread1=new MyThread1();
		 
		  MyThread2 myThread2=new MyThread2();
		     Thread thread=new Thread(myThread2);
		     
		   
		  MyThread3 myThread3=new MyThread3();
		 
		  MyThread4 myThread4=new MyThread4();
		  Thread thread2=new Thread(myThread4);
		  
		     thread.start();
	     mThread1.start();
	     myThread3.start();
	     thread2.start();
	     
	}

}
