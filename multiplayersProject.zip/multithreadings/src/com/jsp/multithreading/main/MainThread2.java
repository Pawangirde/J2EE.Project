package com.jsp.multithreading.main;

import com.jsp.multithreading.threads.MyThread2;

public class MainThread2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     MyThread2 myThread2=new MyThread2();
     Thread thread=new Thread(myThread2);
     thread.start();
     
	}

}
