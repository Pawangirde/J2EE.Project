package com.jsp.multithreading.threads;

public class MyThread2 implements Runnable {
	public void run() {
		for (int i = 0; i <= 5; i++) {
			System.out.println("mythread2 is now running");
		}
	}

}
