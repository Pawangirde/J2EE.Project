package com.jsp.multithreading.threads;

public class MyThread4 implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("mythread4 is now running ");
	}

}
