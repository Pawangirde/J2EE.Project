package com.jsp.multithreading.threads;

public class MyThread1 extends Thread{
      @Override
    public void run() {
    	// TODO Auto-generated method stub
    	for (int i = 0; i <= 5; i++) {
			System.out.println("mythread1 is now running");
		}
    }
}
