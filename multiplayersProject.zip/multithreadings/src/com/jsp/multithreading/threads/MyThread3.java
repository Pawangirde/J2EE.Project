package com.jsp.multithreading.threads;

public class MyThread3 extends Thread {

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("mythread3 is now running");
	}
}
