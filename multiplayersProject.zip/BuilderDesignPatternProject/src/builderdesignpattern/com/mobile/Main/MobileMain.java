package builderdesignpattern.com.mobile.Main;

import builderdesignpattern.com.mobile.Mobile;
import builderdesignpattern.com.mobile.Builder.MobileBuilder;

public class MobileMain {
public static void main(String[] args) {
	Mobile mobile=new MobileBuilder().
			brand("Samsung").price(100000.00)
			.color("red").getMobile();
	System.out.println(mobile);
}
}
