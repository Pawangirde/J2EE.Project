package com.account.program;

import com.account.program.wifehusband.threads.Husband;
import com.account.program.wifehusband.threads.Wife;

public class AccountMain {

	public static void main(String[] args) {
		// Wife wife=new Wife(account);
		// Husband husband=new Husband(account);
		Wife wife = new Wife();
		wife.start();
		Husband husband = new Husband();
		husband.start();

	}

}
