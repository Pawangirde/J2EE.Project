package com.account.program.wifehusband.threads;

import com.account.program.Account;

public class Wife extends Thread {
//	Account account;
//
//	public Wife(Account account) {
//		super();
//		this.account = account;
//	}

	
@Override
public void run() {
	(Account.getAccount()).deposit(5000);
	(Account.getAccount()).widraw(7000);
}
}
