package com.account.program;

import com.account.program.wifehusband.threads.Husband;
import com.account.program.wifehusband.threads.Wife;

public class Account{
	
	static Account account=new Account(10000);
	//static int count;
	int accountbalence;
	
	private Account(int accountbalence) {
		super();
		this.accountbalence = accountbalence;
	}

	

	public static Account getAccount() {

	//	System.out.println("object created  "+count+" times");
		return account;
	}
	

	public synchronized void widraw(int widrawAmount)
	{
		if (accountbalence>=widrawAmount) {
			System.out.println("widrawing "+widrawAmount+ " from the account");
			accountbalence-=widrawAmount;
			System.out.println("available balence :- "+ accountbalence);
		}
			else {
				System.out.println("Insufficient balence");
			}
			
			
		}
	

	public synchronized void deposit(int depositAmount) {
		
		System.out.println("Depositing Amount "+depositAmount+" rupes in the account");
		accountbalence+=depositAmount;
		System.out.println("available balence :- "+ accountbalence);
	}
    

		
	}

	

