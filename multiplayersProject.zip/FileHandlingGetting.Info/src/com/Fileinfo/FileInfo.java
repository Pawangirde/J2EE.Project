package com.Fileinfo;

import java.io.File;
import java.io.IOException;

public class FileInfo {

	public static void main(String[] args) {
		File file = new File("file info.txt");
		if (file.exists()) {
			System.out.println(file.getName() + " Already Exists");
			System.out.println(file.getAbsolutePath() + " is the file path");
		} else {
			try {
				file.createNewFile();
			} catch (IOException e) {

				e.printStackTrace();
			}
			System.out.println(file.getName() + " file is created");
			System.out.println(file.getAbsolutePath() + " is the file path");
		}
		if (file.canRead()) {
			System.out.println("file is readable");
		} else {
			System.out.println("file not readable");
		}
		if (file.canWrite()) {
			System.out.println("file is writable");
		}
		else {
			System.out.println("File not Writable");
		}
		if (file.canExecute()) {
			System.out.println("file is execute");
		}
		else {
			System.out.println("file is not execute");
		}
	}

}
