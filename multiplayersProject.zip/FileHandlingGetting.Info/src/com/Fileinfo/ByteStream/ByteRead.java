package com.Fileinfo.ByteStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class ByteRead {

	public static void main(String[] args) {
		File file = new File("byte_file.txt");
		if (file.exists()) {
			System.out.println(file.getName() + " Already Exists");
			System.out.println(file.getAbsolutePath() + " is the file path");
		} else {
			try {
				file.createNewFile();
			} catch (IOException e) {

				e.printStackTrace();
			}
			System.out.println(file.getName() + " file is created");
			System.out.println(file.getAbsolutePath() + " is the file path");
		}
	try {
		FileInputStream fileInputStream=new FileInputStream(file);
		try {
			int read=fileInputStream.read();
			System.out.println(read);
			System.out.println("data read from the succesfully");
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	} catch (FileNotFoundException e) {
		
		e.printStackTrace();
	}

}}
