package com.Fileinfo.ByteStream;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteWrite {

	public static void main(String[] args) {
		File file = new File("byte_file.txt");
		if (file.exists()) {
			System.out.println(file.getName() + " Already Exists");
			//System.out.println(file.getAbsolutePath() + " is the file path");
		} else {
			try {
				file.createNewFile();
			} catch (IOException e) {

				e.printStackTrace();
			}
			System.out.println(file.getName() + " file is created");
			//System.out.println(file.getAbsolutePath() + " is the file path");
		}
    try (FileOutputStream fileOutputStream = new FileOutputStream(file)) {
		try {
			fileOutputStream.write(45);
			System.out.println("data written succesfully ");
			fileOutputStream.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

}
