package com.jspiders.JDBC.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbc {
public static void main(String[] args) {
	// step1: load the drivers class
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
	
		// step 2:open connection  
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/wajm4?user=root&password=root");
		

		// step 3: create/prepare statement 
		
	
	
		Statement statement=connection.createStatement();
			
		ResultSet resultSet=statement.executeQuery("select * from students");
		
		// step 4: process the result 
		while(resultSet.next()) {
			System.out.println(resultSet.getInt(1)+" "+resultSet.getString(2)+" "+resultSet.getLong(3));
		}
		
		// step 5: close connection
		connection.close();
		statement.close();
		resultSet.close();
	} catch (ClassNotFoundException|SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	}
}
