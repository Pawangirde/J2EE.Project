package jdbc.create.properties.jdbc.code.Standeredization;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JdbcSelect {
	private static Connection connection;
	private static Statement statement;
	private static ResultSet resultset;
	private static FileReader fileReader;
	private static Properties properties;
	private static String query = "select * from students";
	private static String filepath = "C:\\J2EE\\jdbc.create.properties\\Resources\\db_info";
	private static String driverpath = "com.mysql.cj.jdbc.Driver";
	private static String dburl = "jdbc:mysql://localhost:3306/wajm4";

	public static void main(String[] args) {
		try {
			Class.forName(driverpath);

			fileReader = new FileReader(filepath);

			properties = new Properties();
			properties.load(fileReader);

			connection = DriverManager.getConnection(dburl, properties);

			statement = connection.createStatement();

			resultset = statement.executeQuery(query);

			while (resultset.next()) {
				System.out.println(
						resultset.getString(1) + " | " + resultset.getString(2) + " | " + resultset.getString(3)+" | ");
			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (connection != null) {
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				if (statement != null) {
					try {
						statement.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
					if (resultset != null) {
						try {
							resultset.close();
						} catch (SQLException e) {
							e.printStackTrace();
						}
					}
				}
			}
		}
	}
}
