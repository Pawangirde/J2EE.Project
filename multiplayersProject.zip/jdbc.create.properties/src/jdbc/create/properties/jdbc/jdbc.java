package jdbc.create.properties.jdbc;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class jdbc {
	public static void main(String[] args) {
//	step 1: load driver class
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");

			// loading the db_info file in filereader object

			FileReader fileReader = new FileReader("C:\\J2EE\\jdbc.create.properties"
					+"\\Resources\\db_info");// we need to write db_info in the path
			 

																											 
			// loading the file as properties as jdbc

			Properties properties = new Properties();
			properties.load(fileReader);

			// step 2: open connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/wajm4", properties);

			// step 3: create statement
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from students");

//			step 4: process result

			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1) + " | " + resultSet.getString(2) + " | " + resultSet.getLong(3));
			}

//			step 5: close connection

			connection.close();
			statement.close();
			resultSet.close();

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
