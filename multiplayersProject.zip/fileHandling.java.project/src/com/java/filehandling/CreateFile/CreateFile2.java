package com.java.filehandling.CreateFile;

import java.io.File;
import java.io.IOException;

public class CreateFile2 {
public static void main(String[] args) {
	File file=new File("demo.php");
	try {
		if (file.exists()) {
			System.out.println("File already Exists ");
		}
		else {
			file.createNewFile();
			System.out.println(" created new file");
		}
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
