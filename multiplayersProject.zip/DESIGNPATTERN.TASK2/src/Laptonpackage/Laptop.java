package Laptonpackage;

public class Laptop {
	/**
	 * @param brand
	 * @param displaySize
	 * @param ram
	 * @param storageType
	 * @param storageSize
	 * @param graphicCard
	 * @param displayResolution
	 * @param price
	 * @param warranty
	 * @param discount
	 */
	private String brand;
	private double displaySize;
	private int ram;
	private int storageType;
	private int storageSize;
	private int graphicCard;
	private int displayResolution;
	private double price;
	private int Warranty;
	private int discount;

	@Override
	public String toString() {
		return "Laptop [brand=" + brand + ", displaySize=" + displaySize + ", ram=" + ram + ", storageType="
				+ storageType + ", storageSize=" + storageSize + ", graphicCard=" + graphicCard + ", displayResolution="
				+ displayResolution + ", price=" + price + ", Warranty=" + Warranty + ", discount=" + discount + "]";
	}

	public Laptop(String brand, double displaySize, int ram, int storageType, int storageSize, int graphicCard,
			int displayResolution, double price, int warranty, int discount) {
		super();
		this.brand = brand;
		this.displaySize = displaySize;
		this.ram = ram;
		this.storageType = storageType;
		this.storageSize = storageSize;
		this.graphicCard = graphicCard;
		this.displayResolution = displayResolution;
		this.price = price;
		Warranty = warranty;
		this.discount = discount;
	}

}
