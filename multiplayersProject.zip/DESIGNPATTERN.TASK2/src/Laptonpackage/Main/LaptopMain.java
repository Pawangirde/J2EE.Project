package Laptonpackage.Main;

import Laptonpackage.Laptop;
import Laptonpackage.LaptopBuilder.LaptopBuilder;

public class LaptopMain {
public static void main(String[] args) {
	Laptop laptop=new LaptopBuilder().brand("HP").price(50000).getLaptop();
	System.out.println(laptop);
}
}
