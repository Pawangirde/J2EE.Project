package deserialization.Read;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

import serialization.write.Student;

public class Deserializationread {

	public static void main(String[] args) {
		try {
			FileInputStream fileInputStream=new FileInputStream("student");
			try {
				ObjectInputStream objectInStr=new ObjectInputStream(fileInputStream);
			try {
				Student student=(Student)objectInStr.readObject();
				System.out.println(student);
				objectInStr.close();
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			}
			} catch (IOException e) {
				
				e.printStackTrace();
			}
			
		} catch (FileNotFoundException e) {
		
			e.printStackTrace();
		}

	}

}
