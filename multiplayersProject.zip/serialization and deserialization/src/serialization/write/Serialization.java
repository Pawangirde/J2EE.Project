package serialization.write;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serialization {

	public static void main(String[] args) {
		File file=new File("student.txt");
		try {
			file.createNewFile();
			FileOutputStream fileOutputStream=new FileOutputStream("student.txt");
					Student student=new Student();
			student.setId(23);
			student.setName("pawanya");
			student.setEmail("pawanya@gmail.com");
			student.setAddress("wardha");
			
			ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(student);
			System.out.println("object written to file sucessfully");
			objectOutputStream.close();
			
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
