package com.multiplayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SongOperation {
	private static List<Song> playlist = new ArrayList<Song>();
	private static Scanner scanner = new Scanner(System.in);
	private static int choice;
	private static Song song;

	public static void displayallsong() {

	
		for (int i = 0; i < playlist.size(); i++) {
			System.out.println(i + 1 + " " + playlist.get(i).getSongname());
		}

	}

	public static void addsong() {
		
		System.out.println("enter the all song ");
		choice = scanner.nextInt();
		for (int i = 1; i <= choice; i++) {
			song = new Song();
			System.out.println("enter the id of the song");
			int id = scanner.nextInt();
			song.setId(id);
			System.out.println("enter the song name");
			String songname = scanner.nextLine();
			song.setSongname(songname);

			
			System.out.println("enter the album name");
			String album = scanner.nextLine();
			song.setAlbum(album);
			
			System.out.println("Enter the Singer Name");
			String singer = scanner.nextLine();
			song.setSinger(singer);
			
			System.out.println("Enter The lyricist Name");
			String lyricist=scanner.nextLine();
			song.setLyricist(lyricist);
			
			System.out.println("Enter The Duration Time");
			double duration=scanner.nextDouble();
			song.setDuration(duration);
			
			playlist.add(song);
			

		}
	}

}
