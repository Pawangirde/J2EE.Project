package com.multiplayer;

public class Song {
private int id;
private String songname;
private String album;
private String singer;
private String lyricist;
private double duration;


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getSongname() {
	return songname;
}
public void setSongname(String songname) {
	this.songname = songname;
}
public String getAlbum() {
	return album;
}
public void setAlbum(String album) {
	this.album = album;
}
public String getSinger() {
	return singer;
}
public void setSinger(String singer) {
	this.singer = singer;
}
public String getLyricist() {
	return lyricist;
}
public void setLyricist(String lyricist) {
	this.lyricist = lyricist;
}
public double getDuration() {
	return duration;
}
public void setDuration(double duration) {
	this.duration = duration;
}








}

