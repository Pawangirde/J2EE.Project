package com.multiplayer;

import java.util.Scanner;

public class MainClass {
	private static int choose; 
		
	
public static void Methodcaling() {
	Scanner sc=new Scanner(System.in);
	System.out.println("   *# Menu #*\n "
			+" Add Or Remove Songs\n "
			+" Play Songs\n "
			+" Edit Songs\n "
			+" Back ");
	
		System.out.println("Enter the number");
		choose=sc.nextInt();
		switch (choose) {
		case 1:
			System.out.println("Enter the Addsong number");
			 int Addsongs=sc.nextInt();
			 switch (Addsongs) {
			case 1:if (Addsongs==1) {
				SongOperation.addsong();
				System.err.println("added");
			}
			else {
				SongOperation.displayallsong();
			}
				
				
				
			case 2:
			
			default:
				break;
			}
			
			break;

		default:
			break;
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Methodcaling();
	}

}
