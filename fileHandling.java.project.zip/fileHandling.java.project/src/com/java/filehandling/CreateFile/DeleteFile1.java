package com.java.filehandling.CreateFile;

import java.io.File;

public class DeleteFile1 {
public static void main(String[] args) {
	File file=new File("demo.php");
	//file.delete();
	
    if (file.exists()) {
    	file.delete();
    	System.out.println("file now deleted");
		
	}else {
		System.out.println("file does not exists");
	}
}
}
