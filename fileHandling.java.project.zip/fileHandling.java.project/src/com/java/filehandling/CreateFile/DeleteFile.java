package com.java.filehandling.CreateFile;

import java.io.File;

public class DeleteFile {
public static void main(String[] args) {
	File file=new File("C:\\\\Users\\\\pawan\\\\OneDrive\\\\Desktop\\\\demo.png");
	//file.delete();
	
    if (file.exists()) {
    	file.delete();
    	System.out.println("file now deleted");
		
	}else {
		System.out.println("file does not exists");
	}
}
}
