package Laptonpackage.LaptopBuilder;

import Laptonpackage.Laptop;

public class LaptopBuilder {
	private String brand;
	private double displaySize;
	private int ram;
	private int storageType;
	private int storageSize;
	private int graphicCard;
	private int displayResolution;
	private double price;
	private int Warranty;
	private int discount;

	public LaptopBuilder brand(String brand) {
		this.brand = brand;
		return this;
	}

	public LaptopBuilder displaySize(double displaySize) {
		this.displaySize = displaySize;
		return this;
	}

	public LaptopBuilder ram(int ram) {
		this.ram = ram;
		return this;
	}

	public LaptopBuilder storageType(int storageType) {
		this.storageType = storageType;
		return this;
	}

	public LaptopBuilder storageSize(int storageSize) {
		this.storageSize = storageSize;
		return this;
	}

	public LaptopBuilder graphicCard(int graphicCard) {
		this.graphicCard = graphicCard;
		return this;
	}

	public LaptopBuilder displayResolution(int displayResolution) {
		this.displayResolution = displayResolution;
		return this;
	}

	public LaptopBuilder price(double price) {
		this.price = price;
		return this;
	}

	public LaptopBuilder Warranty(int Warranty) {
		this.Warranty = Warranty;
		return this;
	}

	public LaptopBuilder discount(int discount) {
		this.discount = discount;
		return this;
	}
	public Laptop getLaptop()
	{
		Laptop laptop=new Laptop(brand, displaySize, ram, storageType, storageSize, graphicCard, displayResolution, price, Warranty, discount);
	    return laptop;
	}
}
