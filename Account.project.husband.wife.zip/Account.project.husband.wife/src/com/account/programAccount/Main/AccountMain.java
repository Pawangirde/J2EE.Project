package com.account.programAccount.Main;

import com.account.program.Account;
import com.account.program.wifehusband.threads.Husband;
import com.account.program.wifehusband.threads.Wife;

public class AccountMain {
public static void main(String[] args) {
	//Account account=new Account(10000);
	
	
}
}
