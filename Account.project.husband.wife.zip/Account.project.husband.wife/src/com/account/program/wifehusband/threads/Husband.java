package com.account.program.wifehusband.threads;

import com.account.program.Account;

public class Husband extends Thread {

	Account account;

	public Husband(Account account) {
		super();
		this.account = account;
	}
	@Override
	public void run() {
		
		account.deposit(5000);
		account.widraw(8000);
	}
}
