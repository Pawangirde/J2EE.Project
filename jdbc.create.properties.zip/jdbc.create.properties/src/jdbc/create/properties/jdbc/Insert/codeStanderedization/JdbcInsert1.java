package jdbc.create.properties.jdbc.Insert.codeStanderedization;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class JdbcInsert1 {
	private static Connection connection;
	private static Statement statement;
	private static int result;
	private static String filepath = "C:\\J2EE\\jdbc.create.properties\\Resource\\db_info.properties";
	private static FileReader fileReader;
	private static Properties properties;

	public static void main(String[] args) {

		try {
			// filereader object class
			fileReader = new FileReader(filepath);

			properties = new Properties();
			properties.load(fileReader);
             // loading driverclass
			Class.forName(properties.getProperty("driverpath"));

			connection = DriverManager.getConnection(properties.getProperty("dburl"), properties);

			statement = connection.createStatement();

			result = statement.executeUpdate(properties.getProperty("query"));
			System.out.println(result + " rows affected");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e2) {
			}
		}
	}
}
