package jdbc.create.properties.jdbc.insertQuery;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class jdbcinsert {
	private static Connection connection;
	private static Statement statement;
//	private static ResultSet resultset;
	private static int results;
	private static FileReader fileReader;
	private static Properties properties;
	private static String query = "insert into students values(4,'Parag',123456)";
	private static String filepath = "C:\\J2EE\\jdbc.create.properties\\Resources\\db_info";
	private static String driverpath = "com.mysql.cj.jdbc.Driver";
	private static String dburl = "jdbc:mysql://localhost:3306/wajm4";

	public static void main(String[] args) {

		try {
			Class.forName(driverpath);

			fileReader = new FileReader(filepath);

			properties = new Properties();
			properties.load(fileReader);

			connection = DriverManager.getConnection(dburl,properties);
			statement = connection.createStatement();

			results = statement.executeUpdate(query);
			System.out.println(results + " rows affected");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
				if (statement != null) {
					statement.close();
				}
			} catch (SQLException e2) {
			}
		}
	}
}
