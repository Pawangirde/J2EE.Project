package Orderspackage;

public interface Order {

	void orderItem();
}
